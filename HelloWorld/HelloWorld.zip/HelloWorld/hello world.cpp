#include<iostream>
int main()
{
    using namespace std;  
    cout << "HelloWorld" << endl;
    cin.get();
    return 0;
}
